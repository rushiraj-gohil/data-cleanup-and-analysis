
DATA ANALYST TAKE-HOME ASSIGNMENT - DATASET README
Files in dataset folder:
- customers.csv
- products.csv
- transactions.csv
- sessions.csv
- support_tickets.csv

Overview:
This is a purposely messy, semi-realistic e-commerce dataset designed to test data cleaning, SQL, Excel, and BI skills, plus critical thinking.
Expect:
- Mixed date formats
- Missing/null values
- Duplicate rows
- Some logically inconsistent entries (e.g., negative prices, resolved before created)
- Occasional future dates

Suggested tasks (recommended ~3-4 hours total):
1) Data cleaning and profiling:
   - Document your data quality observations (top 5 issues).
   - Describe assumptions you make to clean / interpret the data.

2) SQL tasks:
   - Calculate monthly revenue (paid transactions only) and highlight anomalies.
   - Compute retention by cohort (monthly cohorts by signup). Provide the SQL you used.
   - Identify top 10% customers by lifetime spend and list their key behaviors.

3) Excel tasks:
   - Build a cohort table (in Excel) showing retention rates for first 6 months.
   - Create 2 charts that help a product manager understand revenue drivers.

4) BI tasks:
   - Build a dashboard (PowerBI/Tableau/Looker/Metabase) with:
       a) Revenue trend and anomaly annotations
       b) Cohort retention visualization
       c) Support ticket volume vs. payment_status mapping
   - Explain the business questions each dashboard answers.

5) Short answers (max 150 words each):
   - What are the top 3 risks you see when using this dataset for decision-making?
   - If a stakeholder insists on an immediate recommendation to cut costs, what data-driven suggestion would you make, and what caveats would you attach?

Deliverables:
- A PDF or doc with your approach, assumptions, and key findings.
- SQL file with queries.
- Excel workbook.
- Dashboard link or exported dashboard screenshots.
- Note any limitations and next steps.

Important: This assignment is designed to reward thoughtful, documented reasoning. AI may help with syntax, but you must clearly state your assumptions, data-cleaning decisions, and why you took each step.
